public class Librarian extends Member {

    public Librarian(String name, int id) {
        super(name, id);
    }

    public void addBook(Library library, Book book) {
        library.addBook(book);
        System.out.println("Librarian " + this.name + " added the book: " + book.getTitle());
    }

    public void removeBook(Library library, Book book) {
        library.removeBook(book);
        System.out.println("Librarian " + this.name + " removed the book: " + book.getTitle());
    }

    @Override
    public void showDetails() {
        System.out.println("Librarian ID: " + id + ", Name: " + name);
    }
}
