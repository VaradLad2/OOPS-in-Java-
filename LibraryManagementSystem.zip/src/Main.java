public class Main {
    public static void main(String[] args) {
        // Create library
        Library library = new Library();

        // Create books
        Book book1 = new Book("The Great Gatsby", "F. Scott Fitzgerald", "123456789");
        Book book2 = new Book("1984", "George Orwell", "987654321");

        // Create members
        Member member1 = new Member("Alice", 1);
        Librarian librarian = new Librarian("Bob", 100);

        // Show member details
        member1.showDetails();
        librarian.showDetails();

        // Librarian adds books to the library
        librarian.addBook(library, book1);
        librarian.addBook(library, book2);

        // Show books in the library
        library.showBooks();

        // Member borrows and returns a book
        member1.borrowBook(book1);
        member1.returnBook(book1);

        // Librarian removes a book from the library
        librarian.removeBook(library, book2);

        // Show books in the library after removal
        library.showBooks();
    }
}
