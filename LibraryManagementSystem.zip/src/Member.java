public class Member extends Person {
    public Member(String name, int id) {
        super(name, id);
    }

    public void borrowBook(Book book) {
        System.out.println(this.name + " borrowed the book: " + book.getTitle());
    }

    public void returnBook(Book book) {
        System.out.println(this.name + " returned the book: " + book.getTitle());
    }

    @Override
    public void showDetails() {
        System.out.println("Member ID: " + id + ", Name: " + name);
    }
}
